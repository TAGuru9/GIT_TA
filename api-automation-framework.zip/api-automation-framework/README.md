# API Automation Framework

Starter framework for API testing using:

- Java 17
- Gradle
- REST Assured
- JUnit 5
- Cucumber

## What this supports

- Manual QA can contribute using feature files and JSON payloads
- Automation QA can extend service classes and validators
- CI/CD can run suites by tag like `@smoke` and `@regression`

## Run locally

### Smoke
```bash
./gradlew clean test -Denv=qa -Dcucumber.filter.tags="@smoke"
```

### Regression
```bash
./gradlew clean test -Denv=qa -Dcucumber.filter.tags="@regression"
```

### UAT
```bash
./gradlew clean test -Denv=uat -Dcucumber.filter.tags="@user and @regression"
```

## Suggested next steps for your team

1. Replace demo URLs with your real APIs
2. Add OAuth2 or JWT token generation
3. Add DB validation layer
4. Add Allure reporting
5. Add domain services like ClaimsService, MemberService, ProviderService
6. Add Jenkinsfile if Jenkins is your primary CI/CD tool

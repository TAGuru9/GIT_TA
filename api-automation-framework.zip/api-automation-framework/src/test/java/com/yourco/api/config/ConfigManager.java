package com.yourco.api.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.Properties;

public final class ConfigManager {
    private static final Properties PROPERTIES = new Properties();
    private static final String ENV = System.getProperty("env", "qa");

    static {
        try (InputStream is = ConfigManager.class.getClassLoader().getResourceAsStream("application.properties")) {
            if (is == null) {
                throw new RuntimeException("application.properties not found");
            }
            PROPERTIES.load(is);
        } catch (IOException e) {
            throw new RuntimeException("Unable to load application.properties", e);
        }
    }

    private ConfigManager() {}

    public static String getEnv() {
        return ENV;
    }

    public static String getBaseUrl() {
        return getRequiredProperty(ENV + ".baseUrl");
    }

    public static String getApiKey() {
        return getRequiredProperty(ENV + ".apiKey");
    }

    public static int getConnectTimeoutMs() {
        return Integer.parseInt(getRequiredProperty("connect.timeout.ms"));
    }

    public static int getReadTimeoutMs() {
        return Integer.parseInt(getRequiredProperty("read.timeout.ms"));
    }

    public static String getRequiredProperty(String key) {
        String value = PROPERTIES.getProperty(key);
        if (Objects.isNull(value) || value.isBlank()) {
            throw new IllegalArgumentException("Missing required property: " + key);
        }
        return value.trim();
    }
}

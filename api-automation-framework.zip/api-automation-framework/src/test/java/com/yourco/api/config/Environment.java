package com.yourco.api.config;

public enum Environment {
    DEV, QA, UAT;

    public static Environment from(String value) {
        return Environment.valueOf(value.trim().toUpperCase());
    }
}

package com.yourco.api.core;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.Map;

public class ApiClient {

    private final RequestSpecification baseSpec;

    public ApiClient() {
        this.baseSpec = RequestSpecFactory.defaultSpec();
    }

    public Response get(String path) {
        return RestAssured.given()
                .spec(baseSpec)
                .when()
                .get(path)
                .then()
                .extract()
                .response();
    }

    public Response get(String path, Map<String, ?> pathParams) {
        return RestAssured.given()
                .spec(baseSpec)
                .pathParams(pathParams)
                .when()
                .get(path)
                .then()
                .extract()
                .response();
    }

    public Response post(String path, Object body) {
        return RestAssured.given()
                .spec(baseSpec)
                .body(body)
                .when()
                .post(path)
                .then()
                .extract()
                .response();
    }

    public Response put(String path, Object body) {
        return RestAssured.given()
                .spec(baseSpec)
                .body(body)
                .when()
                .put(path)
                .then()
                .extract()
                .response();
    }

    public Response patch(String path, Object body) {
        return RestAssured.given()
                .spec(baseSpec)
                .body(body)
                .when()
                .patch(path)
                .then()
                .extract()
                .response();
    }

    public Response delete(String path) {
        return RestAssured.given()
                .spec(baseSpec)
                .when()
                .delete(path)
                .then()
                .extract()
                .response();
    }
}

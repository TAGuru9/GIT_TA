package com.yourco.api.core;

import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;

public final class ResponseValidator {

    private ResponseValidator() {}

    public static void assertStatusCode(Response response, int expectedStatusCode) {
        Assertions.assertThat(response.getStatusCode())
                .as("Unexpected status code")
                .isEqualTo(expectedStatusCode);
    }

    public static void assertBodyFieldEquals(Response response, String jsonPath, Object expectedValue) {
        Object actualValue = response.jsonPath().get(jsonPath);
        Assertions.assertThat(actualValue)
                .as("Unexpected value for path: " + jsonPath)
                .isEqualTo(expectedValue);
    }

    public static void assertResponseTimeLessThan(Response response, long maxMillis) {
        Assertions.assertThat(response.time())
                .as("Response time exceeded threshold")
                .isLessThan(maxMillis);
    }

    public static void assertSchema(Response response, String schemaPath) {
        response.then().assertThat()
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath(schemaPath));
    }
}

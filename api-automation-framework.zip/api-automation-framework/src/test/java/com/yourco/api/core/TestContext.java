package com.yourco.api.core;

import io.restassured.response.Response;
import java.util.HashMap;
import java.util.Map;

public class TestContext {
    private Response response;
    private final Map<String, Object> data = new HashMap<>();

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    public void put(String key, Object value) {
        data.put(key, value);
    }

    public Object get(String key) {
        return data.get(key);
    }

    public String getString(String key) {
        Object value = data.get(key);
        return value == null ? null : value.toString();
    }

    public Integer getInt(String key) {
        Object value = data.get(key);
        return value == null ? null : Integer.parseInt(value.toString());
    }
}

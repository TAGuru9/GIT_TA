package com.yourco.api.hooks;

import com.yourco.api.core.TestContext;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {

    private final TestContext testContext;

    public Hooks(TestContext testContext) {
        this.testContext = testContext;
    }

    @Before
    public void beforeScenario() {
        System.out.println("===== Starting scenario =====");
    }

    @After
    public void afterScenario() {
        if (testContext.getResponse() != null) {
            System.out.println("Response body:");
            System.out.println(testContext.getResponse().asPrettyString());
        }
        System.out.println("===== Scenario finished =====");
    }
}

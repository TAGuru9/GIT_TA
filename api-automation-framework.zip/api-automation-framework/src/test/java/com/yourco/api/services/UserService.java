package com.yourco.api.services;

import com.yourco.api.core.ApiClient;
import io.restassured.response.Response;
import java.util.Map;

public class UserService {

    private final ApiClient apiClient = new ApiClient();

    public Response getUserById(int userId) {
        return apiClient.get("/api/users/{id}", Map.of("id", userId));
    }

    public Response createUser(Object requestBody) {
        return apiClient.post("/api/users", requestBody);
    }
}

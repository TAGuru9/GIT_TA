package com.yourco.api.steps;

import com.yourco.api.core.ResponseValidator;
import com.yourco.api.core.TestContext;
import com.yourco.api.services.UserService;
import com.yourco.api.utils.JsonUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.Map;

public class UserApiSteps {

    private final TestContext testContext;
    private final UserService userService;

    public UserApiSteps(TestContext testContext) {
        this.testContext = testContext;
        this.userService = new UserService();
    }

    @Given("a user id of {int}")
    public void a_user_id_of(Integer userId) {
        testContext.put("userId", userId);
    }

    @When("I call the get user API")
    public void i_call_the_get_user_api() {
        Integer userId = testContext.getInt("userId");
        testContext.setResponse(userService.getUserById(userId));
    }

    @Then("the response status should be {int}")
    public void the_response_status_should_be(Integer statusCode) {
        ResponseValidator.assertStatusCode(testContext.getResponse(), statusCode);
    }

    @And("the response should contain user id {int}")
    public void the_response_should_contain_user_id(Integer expectedUserId) {
        ResponseValidator.assertBodyFieldEquals(testContext.getResponse(), "data.id", expectedUserId);
    }

    @And("the response should match the user schema")
    public void the_response_should_match_the_user_schema() {
        ResponseValidator.assertSchema(testContext.getResponse(), "schemas/user-schema.json");
    }

    @Given("a create user payload from {string}")
    public void a_create_user_payload_from(String resourcePath) {
        Map<String, Object> payload = JsonUtils.fromJsonFile(resourcePath);
        testContext.put("requestBody", payload);
    }

    @When("I call the create user API")
    public void i_call_the_create_user_api() {
        Object requestBody = testContext.get("requestBody");
        testContext.setResponse(userService.createUser(requestBody));
    }

    @And("the response should contain created user name {string}")
    public void the_response_should_contain_created_user_name(String expectedName) {
        ResponseValidator.assertBodyFieldEquals(testContext.getResponse(), "name", expectedName);
    }
}

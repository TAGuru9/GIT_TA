package com.yourco.api.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public final class JsonUtils {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private JsonUtils() {}

    public static <T> T fromJsonFile(String resourcePath, Class<T> clazz) {
        try (InputStream is = JsonUtils.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new IllegalArgumentException("Resource not found: " + resourcePath);
            }
            return OBJECT_MAPPER.readValue(is, clazz);
        } catch (IOException e) {
            throw new RuntimeException("Unable to read json file: " + resourcePath, e);
        }
    }

    public static Map<String, Object> fromJsonFile(String resourcePath) {
        try (InputStream is = JsonUtils.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new IllegalArgumentException("Resource not found: " + resourcePath);
            }
            return OBJECT_MAPPER.readValue(is, new TypeReference<>() {});
        } catch (IOException e) {
            throw new RuntimeException("Unable to read json file: " + resourcePath, e);
        }
    }
}

package com.yourco.api.utils;

public final class TokenManager {

    private TokenManager() {}

    public static String getBearerToken() {
        return "dummy-token";
    }
}

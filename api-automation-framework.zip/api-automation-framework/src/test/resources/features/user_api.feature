Feature: User API validation

  @smoke @regression @user
  Scenario: Get single user by id
    Given a user id of 2
    When I call the get user API
    Then the response status should be 200
    And the response should contain user id 2
    And the response should match the user schema

  @regression @user
  Scenario: Create user
    Given a create user payload from "payloads/create_user.json"
    When I call the create user API
    Then the response status should be 201
    And the response should contain created user name "Bhavya"
